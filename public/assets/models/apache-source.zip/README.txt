Apache airframe and rotors for untitled tank game
Upstream: FlightGear AH-64D Apache Longbow, Alex Park (MaverickAlex) and contributors.
Project: https://wiki.flightgear.org/AH-64_Apache
Source: https://mirrors.ibiblio.org/flightgear/ftp/Aircraft-2024/apache.zip
Upstream archive SHA-256: cc75638d39308e6609335f3e1c11777d2aac8c5b062ceec3d1a97fb6300ea5fc

The included AC3D model files are unmodified upstream sources under GPL v2 or later.
apache.glb is a modified version distributed under the same license.
See COPYING and apache/read-me.txt. This archive includes the source meshes and the
conversion script for apache.glb. No external textures or FlightGear code are used.

Adaptation: game-scale axis and pivot conversion, smaller set of cockpit details,
replacement of the original pods with the game's separate stores, and updated finishes.

Rebuild with Blender 5.2:
  unzip apache-source.zip convert-apache.py
  blender -b --factory-startup --disable-autoexec --python-exit-code 1 \
    --python convert-apache.py -- apache-source.zip apache.glb
